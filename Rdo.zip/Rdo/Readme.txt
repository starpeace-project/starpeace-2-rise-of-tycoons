This RDO implementation has proven to be the most efficient and secure one so far.
It uses a query queue in the server and has had better results using a small number
of threads to service the queries waiting in this queue.


A thread-safe proxy is also included in this version.



